
package com.example.ledlexus

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.method.ScrollingMovementMethod
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.util.*
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvLog: TextView
    private lateinit var btnConnect: Button
    private lateinit var btnDisconnect: Button
    private lateinit var btnGet: Button
    private lateinit var btnSave: Button
    private lateinit var btnTest: Button
    private lateinit var btnOverrideOn: Button
    private lateinit var btnOverrideOff: Button
    private lateinit var btnPowerOn: Button
    private lateinit var btnPowerOff: Button
    private lateinit var etR: EditText
    private lateinit var etG: EditText
    private lateinit var etB: EditText
    private lateinit var btnSetColor: Button
    private lateinit var sbBrightness: SeekBar
    private lateinit var tvBr: TextView
    private lateinit var btnSetBr: Button
    private lateinit var sbSpeed: SeekBar
    private lateinit var tvSpd: TextView
    private lateinit var btnSetSpd: Button
    private lateinit var etDyn: EditText
    private lateinit var etOn: EditText
    private lateinit var etOff: EditText
    private lateinit var btnSetEffects: Button
    private lateinit var etCmd: EditText
    private lateinit var btnSend: Button
    private lateinit var swAutoconnect: Switch

    private val mainHandler = Handler(Looper.getMainLooper())

    private var adapter: BluetoothAdapter? = null
    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var out: OutputStream? = null
    @Volatile private var readerThreadRunning = false
    @Volatile private var autoConnectEnabled = true

    private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val TARGET_NAME = "led Lexus"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        tvLog = findViewById(R.id.tvLog)
        tvLog.movementMethod = ScrollingMovementMethod()

        btnConnect = findViewById(R.id.btnConnect)
        btnDisconnect = findViewById(R.id.btnDisconnect)
        btnGet = findViewById(R.id.btnGet)
        btnSave = findViewById(R.id.btnSave)
        btnTest = findViewById(R.id.btnTest)
        btnOverrideOn = findViewById(R.id.btnOverrideOn)
        btnOverrideOff = findViewById(R.id.btnOverrideOff)
        btnPowerOn = findViewById(R.id.btnPowerOn)
        btnPowerOff = findViewById(R.id.btnPowerOff)
        etR = findViewById(R.id.etR); etG = findViewById(R.id.etG); etB = findViewById(R.id.etB)
        btnSetColor = findViewById(R.id.btnSetColor)
        sbBrightness = findViewById(R.id.sbBrightness); tvBr = findViewById(R.id.tvBr); btnSetBr = findViewById(R.id.btnSetBr)
        sbSpeed = findViewById(R.id.sbSpeed); tvSpd = findViewById(R.id.tvSpd); btnSetSpd = findViewById(R.id.btnSetSpd)
        etDyn = findViewById(R.id.etDyn); etOn = findViewById(R.id.etOn); etOff = findViewById(R.id.etOff)
        btnSetEffects = findViewById(R.id.btnSetEffects)
        etCmd = findViewById(R.id.etCmd); btnSend = findViewById(R.id.btnSend)
        swAutoconnect = findViewById(R.id.swAutoconnect)

        swAutoconnect.setOnCheckedChangeListener { _, isChecked -> autoConnectEnabled = isChecked }

        sbBrightness.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                tvBr.text = progress.toString()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        sbSpeed.progress = 15
        tvSpd.text = "15"
        sbSpeed.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                var p = progress
                if(p < 1) p = 1
                tvSpd.text = p.toString()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        btnConnect.setOnClickListener { ensurePermissionsAndConnect() }
        btnDisconnect.setOnClickListener { disconnect() }
        btnGet.setOnClickListener { sendLine("GET") }
        btnSave.setOnClickListener { sendLine("SAVE") }
        btnTest.setOnClickListener { sendLine("TEST") }
        btnOverrideOn.setOnClickListener { sendLine("OVR 1") }
        btnOverrideOff.setOnClickListener { sendLine("OVR 0") }
        btnPowerOn.setOnClickListener { sendLine("POWER 1") }
        btnPowerOff.setOnClickListener { sendLine("POWER 0") }
        btnSetColor.setOnClickListener {
            val r = etR.text.toString().ifEmpty { "255" }
            val g = etG.text.toString().ifEmpty { "160" }
            val b = etB.text.toString().ifEmpty { "20" }
            sendLine("C $r $g $b")
        }
        btnSetBr.setOnClickListener { sendLine("B ${sbBrightness.progress}") }
        btnSetSpd.setOnClickListener { var p = sbSpeed.progress; if(p < 1) p = 1; sendLine("SPD $p") }
        btnSetEffects.setOnClickListener {
            val dyn = etDyn.text.toString().ifEmpty { "1" }
            val on = etOn.text.toString().ifEmpty { "1" }
            val off = etOff.text.toString().ifEmpty { "1" }
            sendLine("DYN $dyn"); sendLine("ON $on"); sendLine("OFF $off")
        }
        btnSend.setOnClickListener { sendLine(etCmd.text.toString()) }

        adapter = BluetoothAdapter.getDefaultAdapter()
        if(adapter == null){
            appendLog("Bluetooth not supported on this device")
            btnConnect.isEnabled = false
        }

        // Auto-connect on start if switch is on
        swAutoconnect.isChecked = true
        autoConnectEnabled = true
        ensurePermissionsAndConnect()
    }

    private fun ensurePermissionsAndConnect() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
                needed += Manifest.permission.BLUETOOTH_CONNECT
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED)
                needed += Manifest.permission.BLUETOOTH_SCAN
        }
        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), 1001)
        } else {
            connectAsync()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001) {
            if (grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                connectAsync()
            } else {
                appendLog("Bluetooth permissions denied")
            }
        }
    }

    private fun connectAsync() {
        thread {
            tryReconnectLoop()
        }
    }

    @SuppressLint("MissingPermission")
    private fun tryReconnectLoop() {
        while (autoConnectEnabled && (socket == null || !socket!!.isConnected)) {
            try {
                val ad = adapter ?: return
                if (!ad.isEnabled) {
                    mainHandler.post {
                        tvStatus.text = "Bluetooth disabled. Please enable."
                        startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
                    }
                    Thread.sleep(2000)
                    continue
                }
                mainHandler.post { tvStatus.text = "Searching bonded device: $TARGET_NAME" }
                val bonded: Set<BluetoothDevice> = ad.bondedDevices
                val dev = bonded.firstOrNull { (it.name ?: "") == TARGET_NAME }
                if (dev == null) {
                    mainHandler.post { appendLog("Device '$TARGET_NAME' not paired. Pair in system settings with PIN 5566.") }
                    Thread.sleep(3000)
                    continue
                }

                mainHandler.post { tvStatus.text = "Connecting to ${dev.name} ..." }
                val sock = dev.createRfcommSocketToServiceRecord(SPP_UUID)
                ad.cancelDiscovery()
                sock.connect()

                socket = sock
                out = sock.outputStream
                mainHandler.post { tvStatus.text = "Connected to ${dev.name}" }
                appendLog("Connected")

                startReaderThread(sock)

                break
            } catch (e: Exception) {
                appendLog("Connect error: ${e.message}")
                Thread.sleep(1500)
            }
        }
    }

    private fun startReaderThread(sock: BluetoothSocket) {
        if (readerThreadRunning) return
        readerThreadRunning = true
        thread {
            try {
                val reader = BufferedReader(InputStreamReader(sock.inputStream))
                while (sock.isConnected) {
                    val line = reader.readLine() ?: break
                    appendLog("<< $line")
                }
            } catch (e: Exception) {
                appendLog("Read thread end: ${e.message}")
            } finally {
                readerThreadRunning = false
                disconnect()
                if (autoConnectEnabled) {
                    appendLog("Reconnecting ...")
                    connectAsync()
                }
            }
        }
    }

    private fun disconnect() {
        try { out?.flush() } catch (_:Exception){}
        try { socket?.close() } catch (_:Exception){}
        socket = null
        out = null
        mainHandler.post { tvStatus.text = "Disconnected" }
    }

    private fun sendLine(s: String) {
        val msg = (s.trim() + "\n").toByteArray()
        thread {
            try {
                val o = out
                if (o == null) {
                    appendLog("Not connected")
                } else {
                    o.write(msg)
                    o.flush()
                    appendLog(">> ${s.trim()}")
                }
            } catch (e: Exception) {
                appendLog("Send error: ${e.message}")
            }
        }
    }

    private fun appendLog(s: String) {
        mainHandler.post {
            val old = tvLog.text.toString()
            val next = (old + (if (old.isEmpty()) "" else "\n") + s).takeLast(4000)
            tvLog.text = next
            val layout = tvLog.layout
            if (layout != null) {
                val scrollAmount = layout.getLineTop(tvLog.lineCount) - tvLog.height
                if (scrollAmount > 0) tvLog.scrollTo(0, scrollAmount) else tvLog.scrollTo(0, 0)
            }
        }
    }
}
